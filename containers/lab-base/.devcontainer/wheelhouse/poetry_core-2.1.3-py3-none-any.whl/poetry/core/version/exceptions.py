from __future__ import annotations


class InvalidVersionError(ValueError):
    pass
